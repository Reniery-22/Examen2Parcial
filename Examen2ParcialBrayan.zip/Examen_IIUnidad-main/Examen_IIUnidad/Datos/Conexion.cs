﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public static class Conexion
    {
        public static string Cadena = "Data Source=Localhost; Initial Catalog=Tickets; User ID=root; Password=gordito 2018";
    }
}
